#include <string>
#include <iostream>
#include <cstring>
using namespace std;

class vect3d {

public:
    vect3d(double a, double b, double c);
    void afficher();
    void testCoincidence(vect3d v);
    vect3d operator+(vect3d v);
    friend double operator*(vect3d v1, vect3d v2);
    int nbrInstance();
    ~vect3d();
private:
   double x,y,z;
   static int compteur;
};

int vect3d::compteur = 0;

vect3d::vect3d(double c1=0.0,double c2=0.0,double c3=0.0){
    x=c1;
    y=c2;
    z=c3;
    compteur++;
}
vect3d vect3d::operator+(vect3d Vector)
	{

		return vect3d(Vector.x + x, Vector.y + y, Vector.z + z);
	}

void vect3d::afficher(){
    cout<< "vecteur ( "<< x << " , " << y << " , "<< z <<" )"<<endl;
}

void vect3d::testCoincidence(vect3d v){
    if(x==v.x && y==v.y && z==v.z){
        cout<<"les deux vecteurs coincident."<<endl;
    }
    else{
        cout<<"les deux vecteurs ne coincident pas."<<endl;
    }
}
double operator*(vect3d v1,vect3d v2){
    cout<<"le produite scalaire est: "<<v1.x*v2.x+v1.y*v2.y+v1.z*v2.z<<endl;
    return v1.x*v2.x+v1.y*v2.y+v1.z*v2.z;
}

int vect3d::nbrInstance(){
    cout<<"le nbr d'instance crees jusqu'a maintenant est :"<<compteur<<endl;
    return compteur;
}

vect3d::~vect3d(){
}

int main()
{
    vect3d v1(1,1,1);
    v1.afficher();
    v1.nbrInstance();
    vect3d v2(1,1,1);
    v1.testCoincidence(v2);
    v2.nbrInstance();
    vect3d d = v1+v2;
    d.afficher();
    cout<<operator*(v1,v2);
    cout<<endl;
    d.nbrInstance();
    return 0;
}

