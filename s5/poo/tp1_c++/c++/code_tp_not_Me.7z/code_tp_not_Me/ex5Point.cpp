#include <iostream>
#include <cstring>
using namespace std;

/////////classe point
class point {
public:
    point(int a, int b);
    void afficher();
protected:
   int x,y;
};
point::point(int a, int b){
    x=a;
    y=b;
}
void point::afficher(){
    cout<<"point("<<x<<","<<y<<")"<<endl;
}

/////////classe cercle
class cercle : public point{
    public:
        cercle(int abs, int ord, double r);
        void afficher();
    private:
        double rayon;
};

cercle::cercle(int abs, int ord, double r):point(abs,ord){
    rayon=r;
}
void cercle::afficher(){
    //cout<<"centre : "<<x<<" , "<<y<<endl;
    cout<<"centre : "; point::afficher();
    cout<<"rayon : "<<rayon<<endl;
    cout<<"x :"<<x;
}

/////////fonction main
int main()
{
    point p1(1,2);
    p1.afficher();
    cercle c1(5,6,2.5);
    c1.afficher();
    return 0;
}

