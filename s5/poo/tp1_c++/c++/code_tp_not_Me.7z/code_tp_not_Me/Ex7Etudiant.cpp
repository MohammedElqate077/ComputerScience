#include <iostream>
#include <cstring>
using namespace std;

////////////////////////////CLASSE Personne
class Personne{
	private:
        char *nom,*prenom, *adresse;
        int age;
 	public:
 		Personne(char*,char*,char*,int);
 		virtual void Affichage();
};

Personne::Personne(char *n,char *p, char *a, int ag){
	nom= new char[strlen(n)+1];
	prenom= new char[strlen(p)+1];
	adresse= new char[strlen(a)+1];
	strcpy(nom,n);
	strcpy(prenom,p);
	strcpy(adresse,a);
	age = ag;
}

void Personne::Affichage(){
            cout<<"Personne -->"<<endl;
			cout<<" Nom: " << nom << " || Prenom: " << prenom << " || adresse: " << adresse<< " || age : "<<age<<endl;
}

////////////////////////////CLASSE Etudiant
class Etudiant: public Personne{
    int code;
    char* filiere;
    float* tabNotes;

    public:
    Etudiant(int, char*, float*, char*,char*, char*, int);
    void Affichage();
    float moyenne();
};
Etudiant::Etudiant(int c, char* f, float* t, char *n,char *p, char *a, int ag):Personne(n,p,a,ag){
    	code=c;
        filiere= new char[strlen(f)+1];
        tabNotes=new float[(sizeof(t)/sizeof(*t))];
        strcpy(filiere,f);
        for(int i=0;i<(sizeof(tabNotes)/sizeof(*tabNotes));i++){
        	tabNotes[i]=t[i];
    	}
    }
void Etudiant::Affichage(){
            cout<<"Etudiant -->"<<endl;
            Personne::Affichage();
			cout<<" code: " << code << " || filieres: " << filiere << " || tabNotes: " <<endl;
			for(int i=0;i<(sizeof(tabNotes)/sizeof(*tabNotes));i++){
        		cout<<tabNotes[i]<<endl;
    		}
}
float Etudiant::moyenne(){
    float tmp=0;
    for(int i=0;i<(sizeof(tabNotes)/sizeof(*tabNotes));i++){
        tmp+=tabNotes[i];
    }
    return tmp/(sizeof(tabNotes)/sizeof(*tabNotes));
}
////////////////////////////CLASSE Enseignant
class Enseignant: public Personne{
    int nbrHeure;
    float tauxHoraire;

    public:
    Enseignant(int, float, char*, char*, char*, int);
    void Affichage();
    float CalculeSalaire();
};
Enseignant::Enseignant(int nbrh, float TH, char *n,char *p, char *a, int ag):Personne(n,p,a,ag){
    	nbrHeure=nbrh;
        tauxHoraire = TH;
}
void Enseignant::Affichage(){
            cout<<"Enseignant -->"<<endl;
            Personne::Affichage();
			cout<<" Nombre d'heures: " << nbrHeure << " || Tautx horaire: " << tauxHoraire <<endl;
}
float Enseignant::CalculeSalaire(){
    return nbrHeure * tauxHoraire;
}
////////////////////////////EtudiantVacataire
class EtudiantVacataire: public Etudiant, public Enseignant{
    int nbrHeure;
    float tauxHoraire;

    public:
    EtudiantVacataire(int, float, int, char*, float*, char*, char*, char*,int);
    void Affichage();
};
EtudiantVacataire::EtudiantVacataire(int nbrh, float TH, int c, char* f, float* t, char *n,char *p, char *a, int ag):Enseignant(nbrh,TH,n,p,a,ag),Etudiant(c,f,t,n,p,a,ag){
}
void EtudiantVacataire::Affichage(){
            cout<<"Etudiant Vacataire -->"<<endl;
            Etudiant::Affichage();
            //Enseignant::Affichage();
}
////////////////////////////fonction main
int main(){
    float* t = new float[2];
    t[0]=10;
    t[1]=11;
    cout<<" "<<endl;
    Personne p("Nom1", "Prenom1", "adresse1", 20);
    Etudiant etudiant(12, "analyse,algebre", t,"Nom1", "Prenom1", "adresse1", 20);
    Enseignant ens(6,60,"Nom1", "Prenom1", "adresse1", 20);
    EtudiantVacataire ev(6,60, 12, "analyse,algebre", t,"Nom1", "Prenom1", "adresse1", 20);
    
	etudiant.Affichage();
	cout<<" "<<endl;
	cout<<"Moyenne des notes pour l'etudiant : "<<etudiant.moyenne()<<endl;
    cout<<" "<<endl;
	ens.Affichage();
	cout<<" "<<endl;
	cout<<"Salaire de l'enseignant: '"<<ens.CalculeSalaire()<<endl;
    cout<<" "<<endl;
    
    ev.Affichage();
    return 0;
}
