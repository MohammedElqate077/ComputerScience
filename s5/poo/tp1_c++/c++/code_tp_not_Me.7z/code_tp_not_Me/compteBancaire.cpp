#include <string>
#include <iostream>
#include <cstring>
using namespace std;

class compte {

public:
    compte();
    compte(float s, char *p,char *n);
    void afficher();
    void verser(float s);
    void retirer(float s);
    ~compte();
private:
   static int code;
   char *prenom;
   char *nom;
   float solde;

};

int compte::code = 0;

compte::compte(){
    prenom = new char[20];
    nom = new char[20];
    float s;
    char p[20];
    char n[20];
    cout<<"entrer le solde :";
    cin>>s;
    cout<<"entrer le prenom :";
    cin>>p;
    cout<<"entrer le nom :";
    cin>>n;
    strcpy(prenom,p);
    strcpy(nom,n);
    solde=s;
    code++;
}

compte::compte(float s,char *p, char *n){
    prenom = new char[20];
    nom = new char[20];
    strcpy(prenom,p);
    strcpy(nom,n);
    solde=s;
    code++;
}

void compte::afficher(){
    cout<< "Client : "<< prenom<< " " << nom<< " . Son code est : "<< code<<" . Son solde est : "<< solde;
}

void compte::verser(float s){
    solde = solde+s;
}

void compte::retirer(float s){
    solde = solde-s;
}

compte::~compte(){
    cout<<"destruction du client "<< prenom << " "<<nom<<endl;
    cout<<this;//le pointeur sur l�objet qui l�a appel�e
    cout<<endl;
}

int main()
{
    cout<<"Premier client"<<endl;
    compte c1;
    c1.afficher();
    cout<<endl;
    char *pp = new char[20];
    char *nn = new char[20];
    char p[20]="dddd";
    char n[20]="bbbb";
    strcpy(pp,p);
    strcpy(nn,n);
    cout<<"Deuxieme client"<<endl;
    compte c2(11111111,pp,nn);
    c2.afficher();
    cout<<endl;

    return 0;
}

