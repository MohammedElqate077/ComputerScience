#include <iostream>
#include <cstring>
#include <string>
#include <vector>
using namespace std;

////////////////////////////CLASSE Personne
class Personne{
	protected:
        char *nom,*prenom, *datenaissance;
 	public:
 		Personne(char*,char*,char*);
 		virtual void Affichage();
 		virtual ~Personne();
};

Personne::Personne(char *n,char *p, char *d){
	nom= new char[20];
	prenom= new char[20];
	datenaissance= new char[10];
	strcpy(nom,n);
	strcpy(prenom,p);
	strcpy(datenaissance,d);
}

Personne::~Personne(){
	cout<<"destruction d'une personne "<<endl;
}
void Personne::Affichage(){
            cout<<"Personne -->"<<endl;
			cout<<" Nom: " << nom << " || Prenom: " << prenom << " || Date de naissance: " << datenaissance<<endl;
}

////////////////////////////CLASSE Employe
class Employe: public Personne{
    protected:
		double salaire;
 	public:
 		Employe(char*,char*,char*,double);
 		virtual void Affichage();
 		virtual ~Employe();
};

Employe::Employe(char *n,char *p, char *d,double s):Personne(n,p,d){
	salaire = s;
}

void Employe::Affichage(){
            cout<<"Employe -->";Personne::Affichage();
			cout<<" Salaire: "<< salaire<<endl;
}

Employe::~Employe(){
	cout<<"destruction d'un employe"<<endl;
}

////////////////////////////CLASSE Chef
class Chef: public Employe{
    protected:
		string service;
 	public:
 		Chef(char*,char*,char*,double,string);
 		void Affichage();
 		~Chef();
};

Chef::Chef(char *n,char *p, char *d,double s,string serv):Employe(n,p,d,s){
	service=serv;
}
void Chef::Affichage(){
            cout<<"Chef -->";Employe::Affichage();
			cout<<" Service: "<< service<<endl;
}

Chef::~Chef(){
	cout<<"destruction d'un Chef"<<endl;
}

////////////////////////////fonction main
int main(){
    Employe *P [5];
            //Des Affectations utilisant le concept du polymorphisme
            P[0] =  new Employe("NOM1", "PRENOM1", "1985/3/4", 9000);
            P[1] =  new Employe("NOM2", "PRENOM2", "1984/3/4", 10000);
            P[2] =  new Employe("NOM3", "PRENOM3", "1983/3/4", 8000);
            P[3] =  new Chef("NOM4", "PRENOM4", "1982/3/4", 11000,"SERVICE1");
            P[4] =  new Chef("NOM5", "PRENOM5", "1981/3/4", 7000,"SERVICE2");
    for (int i = 0; i < 5; i++){
                P[i]->Affichage();  //Appel d'une méthode polymorphique (qui prend une nouvelle forme dans les classes dérivées)
                cout<<"*******************************************"<<endl;
    }
    delete[] P;
	/*Personne p1("bbb","dddd","12335");
	p1.Affichage();
	Employe e1("aa","cc","12",200000);
	e1.Affichage();
	Chef c1("AAAAA","BBBB","20/12/2000",30000,"ssssssssssssss");
	c1.Affichage();*/

    /*vector<Personne> array;

    array.push_back(Employe("NOM1", "PRENOM1", "1985, 3, 4", 9000));
    array.push_back(Employe("NOM2", "PRENOM2", "1984, 3, 4", 10000));
    array.push_back(Employe("NOM3", "PRENOM3", "1983, 3, 4", 8000));
    array.push_back(Chef("NOM4", "PRENOM4", "1982, 3, 4", 11000,"SERVICE1"));
    array.push_back(Chef("NOM5", "PRENOM5", "1981, 3, 4", 7000,"SERVICE2"));
    for (int i = 0; i < 5; i++){
        array[i].Affichage();  //Appel d'une méthode polymorphique (qui prend une nouvelle forme dans les classes dérivées)
    }
*/
    return 0;
}
