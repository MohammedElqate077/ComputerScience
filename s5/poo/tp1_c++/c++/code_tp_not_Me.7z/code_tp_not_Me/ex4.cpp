#include <string>
#include <iostream>
#include <cstring>
using namespace std;

static int c=0;
class vecteur {

public:
    vecteur();
    void affichage();
    void remplissage();
    vecteur & operator=(const vecteur &);
    int & operator [] (int) ; //fonction de surdéfinition de l’indexation
    ~vecteur();
private:
   int nmax;
   int *a;
};
vecteur::vecteur(){
    nmax=0;
    a=new int[nmax];
}
vecteur::~vecteur(){
    cout<<"destruction du constructeur";
    delete[] a;
}
void vecteur::remplissage(){
    int nbr;
    cout<<"entrer le nombre de coordonnees:"<<endl;
    cin>>nbr;
    nmax=nbr;
    a=new int[nmax];
    for(int i=0;i<nmax;i++){
        cout<<"entrer un entier :";
        cin>>a[i];
    }
}

void vecteur::affichage(){
        cout<<"Vecteur: (";
        for(int i=0;i<nmax;i++){
            cout<<a[i];
            if(i!=nmax-1) cout<<",";
    }
    cout<<")"<<endl;
}
vecteur& vecteur:: operator = (const vecteur &u) {
    if (this!=&u) {
    delete [] a;
    nmax=u.nmax;
    a=new int[nmax];
    for (int i=0; i<nmax; i++)
        *(a+i) = *(u.a+i) ; }
    else cout <<" on ne fait rien \n"<<endl;;
    return*this;
}
int & vecteur::operator [](int i) {
	cout<<"redefinition de [] "<<endl;
    return *(a+i) ;
}
int main(){
	vecteur v;
	v.remplissage();
	v.affichage();
	//v.operator[](1);
	cout<<"affichage du 2eme indice v[2] "<<v[2]<<endl;

	cout<<"y :"<<endl;
	vecteur y;
	y.affichage();
	y = v;
	y.affichage();
	return 0;
}
