
#include "employe.h"
#include <iostream>

using namespace std;

void employe::afficher_employe(){
    cout<<"le cpde de cet employe est : "<<endl;
}

